<?php
session_start();
//var_dump($_POST);
//Create variables
$_SESSION['user']= $_POST['user'];
$pAttempt = $_POST['pwd'];
$pass = "secret";
//Lock user attempts at password to three tries
if (isset($_SESSION['attempt'])) {
    $attempts = $_SESSION['attempt'];
} else {
    $_SESSION['attempt'] = 3;
}

//Allocate password value
if ($_POST['pwd'] == "secret") {
    $_SESSION['user'] = $_POST['user'];
    header("location: index.php");
} else {
    $_SESSION['msg'] = "Invalid username/password";
    header("location: login.php");
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
