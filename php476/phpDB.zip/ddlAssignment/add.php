<?php session_start()?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stock";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
//check user session
if (isset($_SESSION['user'])) {
    $username = $_SESSION['user'];
} else {
    header("location:login.php");
}
?>
<html>
<div class=page>
<head>
  <!-- Nav Bar Styling and inclusion
  -->
  <style>
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }

  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  /* Change the link color to #111 (black) on hover */
  li a:hover {
    background-color: #111;
  }
  .active {
background-color: #4CAF50;
}
</style>
  <ul>
<li><a href="login.php">Log In</a></li>
<li><a class="active" href="#Add">Create Record</a></li>
<li><a href="modify.php">Delete Record (You will want to view the table first)</a></li>
<li><a href="read.php">View Table</a></li>
</ul>
<!--
Prompt message and form to create records
-->
<h1>   Welcome, <?= $username ?> to create a record in the table fill in the fields below!<br> </h1>
<body>
  <form action="create.php" method="post">
  Product: <input type="text" name="name"><br>
  Price: <input type="text" name="price"><br>
  <input type="submit">
  </form>
</body>
</div>
</html>
<?php
//Created new page for the calculations
//$row_id = $_GET['id'];
//echo $sql;

// sql to delete a record
//$sql = "Insert into products (title, price) VALUES ('MyComputer', '200')";

//if ($conn->query($sql) === TRUE) {
  ///  echo "Record created successfully";
//} else {
  //  $conn->error;
//}

$conn->close();

//header("location:read.php");
?>
