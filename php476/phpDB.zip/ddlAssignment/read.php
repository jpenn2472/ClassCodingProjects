<!DOCTYPE html>
<?php session_start()?>
<?php
//check user session
if (isset($_SESSION['user'])) {
    $username = $_SESSION['user'];
} else {
    header("location:login.php");
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <!-- Nav Bar Styling and inclusion
        -->
        <style>
        ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
          overflow: hidden;
          background-color: #333;
        }

        li {
          float: left;
        }

        li a {
          display: block;
          color: white;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
        }

        /* Change the link color to #111 (black) on hover */
        li a:hover {
          background-color: #111;
        }
        .active {
    background-color: #4CAF50;
  }
  </style>
        <ul>
   <li><a href="login.php">Log In</a></li>
   <li><a href="add.php">Create Record</a></li>
   <li><a href="modify.php">Delete Record (You will want to view the table first)</a></li>
   <li><a class="active" href=#read>View Table</a></li>
  </ul>
    </head>
    <body>
      <!-- Prompt message
      -->
    <h1>  Welcome, <?= $username ?> Create or Delete a record by selecting the option below!<br> </h1>
<div class="records">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "stock";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//Display items in products table and check connection result  <!-- Nav Bar Styling and inclusion
$sql = "SELECT id, title, price FROM products";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     //output data of each row
    while($row = $result->fetch_assoc()) {
        $del_id = $row["id"];
      echo "Item Number: " . $row["id"] . " " . "Name: " . $row["title"]. ", Price: $"
             . $row["price"]. "<br>";
    }
} else {
   echo "0 results";
}
$conn->close();
        ?>
        <!--
        Form for user to select which set of files to View
      -->
      </div>
        <form action="add.php">
    <input type="submit" value="Create Record" />
  </form>
    <form action="modify.php">
<input type="submit" value="Delete Record" />
</form>
    </body>
</html>
