<?php session_start() ?>
<?php
if (isset($_SESSION['user'])) {
    $username = $_SESSION['user'];
} else {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
      <!-- Nav Bar Styling and inclusion
      -->
      <style>
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #333;
      }

      li {
        float: left;
      }

      li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
      }

      /* Change the link color to #111 (black) on hover */
      li a:hover {
        background-color: #111;
      }
      .active {
  background-color: #4CAF50;
}
</style>
      <ul>
 <li><a href="login.php">Log In</a></li>
 <li><a href="add.php">Create Record</a></li>
 <li><a href="modify.php">Delete Record (You will want to view the table first)</a></li>
 <li><a href="read.php">View Table</a></li>
</ul>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
      <!--
      Prompt message and continue button
    -->
        <h4> Welcome, <?=$username?> <br> <h4>
        You have logged in successfully! Click continue to go through the application step by step or use the nav bar to select a page of your choosing!
        <form action="read.php" method="get">
            <input type="submit" value="Continue">
        </form>
    </body>
</html>
