<?php session_start()?>

<?php if (isset($_SESSION['user'])) {
    $username = $_SESSION['user'];
} else {
    header("location:login.php");
}
?>
<html>
<head>
  <style>
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }

  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  /* Change the link color to #111 (black) on hover */
  li a:hover {
    background-color: #111;
  }
  .active {
background-color: #4CAF50;
}
</style>
<!-- Nav Bar Styling and inclusion
-->
  <ul>
<li><a href="login.php">Log In</a></li>
<li><a href="add.php">Create Record</a></li>
<li><a class="active" href=#view>Delete Record (You will want to view the table first)</a></li>
<li><a href="read.php">View Table</a></li>
</ul>
<h1>   Welcome, <?= $username ?> <br> </h1>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stock";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<body>
  <!--
  Form for user to enter which item to delete by item Number
-->
  <form action="delete.php" method="post">
  ProductID to Delete: <input type="text" name="prodId"><br>
  <input type="submit">
  </form>
</body>
</html>
