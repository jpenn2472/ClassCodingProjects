<?php session_start()?>
<?php
//Standard Vars for sql connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stock";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
<?php


 //sql to create a record
$sql =("Insert into products (title, price) VALUES ('".$_POST['name']."', '".$_POST['price']."')");
//check if change was created
if ($conn->query($sql) === TRUE) {
   echo "Record created successfully";
//debug
} else {
  echo "issue with record";
    $conn->error;
}

$conn->close();

header("location:read.php");
?>
