<?php session_start() ?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <!-- Nav Bar Styling and inclusion
        -->
        <style>
        ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
          overflow: hidden;
          background-color: #333;
        }

        li {
          float: left;
        }

        li a {
          display: block;
          color: white;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
        }

        /* Change the link color to #111 (black) on hover */
        li a:hover {
          background-color: #111;
        }
        .active {
    background-color: #4CAF50;
  }
  </style>
        <ul>
   <li><a class="active" href="#login">Log In</a></li>
   <li><a href="add.php">Create Record</a></li>
   <li><a href="modify.php">Delete Record (You will want to view the table first)</a></li>
   <li><a href="read.php">View Table</a></li>
  </ul>
    </head>
    <body>
        <?php
            if (isset($_SESSION['msg'])) {
               echo $_SESSION['msg'];
               $_SESSION['msg'] = '';
            }
           ?>
           <!-- Prompt message and form for Login
           -->
           <h4> Hello! Enter your user name and Password to login! </h4>
        <form action="authenticate.php" method="post">
           Username: <input type="text" name="user">
           Password: <input type="password" name="pwd">
           <input type="submit" value="Login">
        </form>
        <?php
        // put youvar_dump(r code here
        ?>
    </body>
</html>
