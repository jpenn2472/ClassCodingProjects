<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $vendor = $amount = $end = "";
        $vendor = ($_GET['card'] == 0) ? "MasterCard" : ($_GET['card'] == 1) ? "Visa" : "AMEX";
        $amount = $_GET['amt'];
        $end = $_GET['end'];
        
        echo "Your $vendor card ending with $end was charged $$amount.";
        ?>
    </body>
</html>
