<?php session_start()?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stock";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$row_id = $_POST['prodId'];
//echo $row_id;

// sql to delete a record
$sql = "DELETE FROM products WHERE id=$row_id";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    $conn->error;
}

$conn->close();

header("location:read.php");
?>
