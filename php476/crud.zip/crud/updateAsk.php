<?php
session_start();
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//form for input
?>
<html>
<body>

<form action="update.php" method="post">
<p> This first box is the name on the record currently </p>
Name: <input type="text" name="name"><br>
<p> This second box is where you will enter the name to replace what is currently on the record. </p>
Update: <input type="text" name="updateName"><br>
Update DoB (1994-12-24) : <input type="date" name="dob"><br>
Update Gender: <input type="text" name="updateGender"><br>
<input type="submit">
</form>

</body>
</html>
