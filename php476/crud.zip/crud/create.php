<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
//Store form variables
$name = $_POST['name'];
$gender = $_POST['Gender'];
$dob = $_POST['DoB'];
//insert query
$sql = ("INSERT INTO person (name, gender, dob)
VALUES  ('$name', '$gender', '$dob')");
//validate
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
//go home
$conn->close();
header("location:index.php");
?>
