<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
//create form to recieve data
?>

<html>
<body>

<form action="create.php" method="post">
Name: <input type="text" name="name"><br>
Gender: <input type="text" name="Gender"><br>
DoB: (1994-12-24) <input type="date" name="DoB"><br>
<input type="submit">
</form>

</body>
</html>
