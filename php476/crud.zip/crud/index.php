<?php
session_start();
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$sql    = "SELECT name, gender, dob FROM person";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row["name"] . " - Gender: " . $row["gender"] . " " . $row["dob"] . "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();

// Check connection
//if ($conn->connect_error) {
// die("Connection failed: " . $conn->connect_error);
//}
//echo "Connected successfully";
?>

<ul>
 <li><a href="index.php">View</a></li>
 <li><a href="createForm.php">Create Record</a></li>
 <li><a href="DeleteForm.php">Delete Record</a></li>
 <li><a href="updateAsk.php">Update Record</a></li>
</ul>
