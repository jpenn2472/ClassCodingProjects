
	<?php
session_start();
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>
<html>
<body>

<form action="delete.php" method="post">
  <p> Enter name of the person whose record you want to delete </p>
Name: <input type="text" name="name"><br>
<input type="submit">
</form>

</body>
</html>
