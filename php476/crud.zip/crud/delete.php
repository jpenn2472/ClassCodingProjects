<?php
session_start();
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//store form var
$name = $_POST['name'];
//delete statement
$sql = "DELETE FROM person WHERE name = '$name'";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
//var_dump($name);
header("location:index.php");
?>
