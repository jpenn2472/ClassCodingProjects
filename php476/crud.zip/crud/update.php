<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//store form vars
$name = $_POST['name'];
$updateName = $_POST['updateName'];
$dob = $_POST['dob'];
$updateGender = $_POST['updateGender'];
//update statement
$sql = "UPDATE person SET name='$updateName', dob='$dob' , gender='$updateGender' WHERE name='$name'";
//validate
if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}
//gohome
$conn->close();
header("location:index.php");
?>
