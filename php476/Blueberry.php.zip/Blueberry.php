

<?php
//blueberry.php
// Display numbers and their corresponding words // Using selection and repetition structures
{
  //Counters
$number = 1;
 $blueCount = 0;
 $berryCount = 0;
 $blueberryCount = 0;
//msg prompt
 echo "The folllowing is from a while loop: \n ";
 while ($number<=100)
  {
    //display number and blueberyy if divisible by 15
    if (($number % 15) ==0)
    {
      printf("%d %s\n", $number," Blueberry");
      ++$blueberryCount;
    }
    //display number and blue if divisible by 3
    else
       if (($number % 3) == 0)
     {  printf("%d %s\n", $number, " Blue");
       ++$blueCount;
     }
     //display number and berry if divisible by 5
     else
       if (($number % 5) == 0)
       {
         printf("%d %s\n ", $number, " Berry");
         ++$berryCount;
       }
       //only display number
else {
 echo $number, "\n";
} ++$number;
     }
     //prompt message listing how many of each berry was present in the sequence
     echo "There are ", $blueCount, " Blues.\n";
     echo "There are ", $berryCount, " Berries.\n";
     echo "There are ", $blueberryCount, " Blueberries.\n";
//reset counters
     echo "The following is from a for loop: \n" ;
    $blueCount = 0;
    $berryCount = 0;
    $blueberryCount = 0;
//for loop
for ($number = 1; $number <=100; $number++) {
  //div. by 15 = blueberry
   if (($number % 15) ==0) {
       printf("%d%s\n", $number, " Blueberry");
       $blueberryCount++;
   }
   //div. by 3 = Blue
   else if (($number % 3) == 0) {
               printf("%d%s\n", $number, " Blue");
               $blueCount++;
           }
           //Div. by 5 = Berry
             else if (($number % 5) == 0) {
               printf("%d%s\n", $number, " Berry");
               $berryCount++;
           }
           //display everything else
               else {
                 echo $number, "\n";
           }
}
//Display prompt and how many of each berry is in the sequence
 printf("here are %d Blues.\n", $blueCount);
       printf("There are %d Berries.\n", $berryCount);
       printf("There are %d Blueberries.\n", $blueberryCount);
        // display message for the do...while loop
        printf("The following is from a do...while loop: \n");
          $number = 1;
        $blueCount = 0;
        $berryCount = 0;
        $blueberryCount = 0;

        do {
            // display the number and “Blueberry” when it is divisible by 15
            if ($number % 15 == 0) {
                printf("%3d %s\n", $number, " Blueberry");
                $blueberryCount++;
            }
            //display blue if div. by 3
              else if ($number % 3 == 0) {
                printf("%3d %s\n", $number, "Blue");
                $blueCount++;
            }
            //display berry if div. by 5
            else if ($number % 5 == 0) {
                printf("%3d %s\n", $number, "Berry");
                $berryCount++;
            }
            //display others
            else {
                printf("%3d\n", $number);
            }
                  $number++;
        } while ($number <= 100);
        //prompt message displaying number of each berry in the sequence
          printf("There are %d Blues.\n", $blueCount);
        printf("There are %d Berries.\n", $berryCount);
        printf("There are %d Blueberries.\n", $blueberryCount);

    }
?>
