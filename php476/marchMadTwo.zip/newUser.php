<?php

session_start();
// 1. make sure user is not already in the database
// 2. make sure that pwd and repeat match
// 3. insert a new row
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "march";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username1 = trim($_REQUEST['user']);
$newpwd = $_POST['pwd'];
$hashpassword = password_hash(trim($_REQUEST['pwd']), PASSWORD_DEFAULT);
$repeat = $_POST['repeat'];
//sql select
$sqlsel = "SELECT username FROM users";
$get = $conn->query($sqlsel);
while ($row = $get->fetch_assoc()) {
    if ($row["username"] == $_POST['user']) {
        $_SESSION['error'] = "username or password already in use try again.";
        header("location: index.php");
        exit(1);
    }
}
if (!($newpwd == $repeat)) {
    $_SESSION['error'] = "Passwords do not match";
    header("location: index.php");
    exit(1);
}
$encrypted_pwd = password_hash($newpwd, PASSWORD_DEFAULT);
$sql = "INSERT INTO users(username, password) VALUES('$username1', '$encrypted_pwd')";
if ($conn->query($sql) === TRUE) {
    $_SESSION['username'] = $username1;
    $_SESSION['error'] = '';
    header("location:index.php");
    exit(1);
} else {
    $_SESSION['error'] = "Error: " . $sql . " " . $conn->error;
}

$conn->close();
header("location:index.php");
?>