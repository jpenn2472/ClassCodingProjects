<?php

session_start();
if (!isset($_SESSION['username'])) {
    header("location:index.php");
    // Make sure that code below does not get executed when we redirect.
    exit(1);
}

// TODO: connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "march";

$seed = $_POST['seed'];
$conf = $_POST['conf'];
$schid = $_POST['id'];

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// TODO: update the seed and conference based on the id
$sql = "UPDATE team SET conference='$conf', seed ='$seed' WHERE id='$schid'";
// NOTE: you can't update the team name
// TODO: communicate any errors using the session ('error' key)
if ($conn->query($sql) === TRUE) {
    header("location:index.php");
    exit(1);
} else {
    $_SESSION["Error"] = "error updating record: ";
}
// TODO: close the database connection

mysqli_close($conn);
header("location:index.php");
?>
