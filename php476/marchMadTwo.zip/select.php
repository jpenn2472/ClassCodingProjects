<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("location:index.php");
    // Make sure that code below does not get executed when we redirect.
    exit;
}
include 'menu.html';
// TODO: connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "march";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT seed, school, conference FROM team ORDER BY seed";
$get = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <!-- TODO: display all team data except id -->
        <?php
        while ($row = $get->fetch_assoc()) {

            echo "seed: " . $row["seed"] . " school: " . $row["school"] . " Conference: " . $row["conference"] . ' <a href="do_delete.php">delete</a>' . "<br>";
        }
        ?>

        <!-- TODO: display order must be based on the seed value -->
    </body>
</html>
