CREATE DATABASE march;

USE march;
CREATE TABLE team
(
  id int auto_increment PRIMARY KEY,
  seed int,
  school varchar(50),
  conference varchar(50)
);

CREATE TABLE users 
(
    id int primary key auto_increment, 
    username varchar(255), 
    password varchar(255) 
);

-- insert a row into the users table for the administrator:
-- username = admin
-- password = pwd
INSERT INTO users (username, password) VALUES ('admin', '$2y$10$6EagpQz90eekX4cIlXjWdu/iCCo3jmSPrLmm9kJ/OVzbmwHaJZGzG');

INSERT into team (seed, school, conference) VALUES(1,'Virginia','ACC');
INSERT into team (seed, school, conference) VALUES(1,'Gonzaga','WCC');
INSERT into team (seed, school, conference) VALUES(1,'Duke','ACC');
INSERT into team (seed, school, conference) VALUES(2,'Michigan St.','Big 10');
INSERT into team (seed, school, conference) VALUES(1,'North Carolina','ACC');
INSERT into team (seed, school, conference) VALUES(2,'Michigan','Big 10');
INSERT into team (seed, school, conference) VALUES(2,'Tennessee','SEC');
INSERT into team (seed, school, conference) VALUES(2,'Kentucky','SEC');
INSERT into team (seed, school, conference) VALUES(3,'Houston','AAC');
INSERT into team (seed, school, conference) VALUES(3,'Florida St.','ACC');
INSERT into team (seed, school, conference) VALUES(3,'Kansas','Big 12');
INSERT into team (seed, school, conference) VALUES(3,'LSU','SEC');
INSERT into team (seed, school, conference) VALUES(4,'Texas Tech','Big 12');
INSERT into team (seed, school, conference) VALUES(4,'Purdue','Big 10');
INSERT into team (seed, school, conference) VALUES(4,'Wisconsin','Big 10');
INSERT into team (seed, school, conference) VALUES(4,'Buffalo','MAC');
INSERT into team (seed, school, conference) VALUES(5,'Kansas St.','Big 12');
INSERT into team (seed, school, conference) VALUES(5,'Auburn','SEC');
INSERT into team (seed, school, conference) VALUES(5,'Virginia Tech','ACC');
INSERT into team (seed, school, conference) VALUES(5,'Villanova','Big East');
INSERT into team (seed, school, conference) VALUES(6,'Maryland','Big 10');
INSERT into team (seed, school, conference) VALUES(6,'Wofford','Southern');
INSERT into team (seed, school, conference) VALUES(6,'Mississippi St.','SEC');
INSERT into team (seed, school, conference) VALUES(6,'Iowa St.','Big 12');
INSERT into team (seed, school, conference) VALUES(7,'Cincinnati','AAC');
INSERT into team (seed, school, conference) VALUES(7,'Nevada','MWC');
INSERT into team (seed, school, conference) VALUES(7,'Marquette','Big East');
INSERT into team (seed, school, conference) VALUES(7,'Louisville','ACC');
INSERT into team (seed, school, conference) VALUES(8,'Washington','Pac 12');
INSERT into team (seed, school, conference) VALUES(8,'Iowa','Big 10');
INSERT into team (seed, school, conference) VALUES(8,'Oklahoma','Big 12');
INSERT into team (seed, school, conference) VALUES(8,'UCF','AAC');
INSERT into team (seed, school, conference) VALUES(9,'Utah St.','MWC');
INSERT into team (seed, school, conference) VALUES(9,'Minnesota','Big 10');
INSERT into team (seed, school, conference) VALUES(9,'NC State','ACC');
INSERT into team (seed, school, conference) VALUES(9,'Seton Hall','Big East');
INSERT into team (seed, school, conference) VALUES(10,'TCU','Big 12');
INSERT into team (seed, school, conference) VALUES(10,'Syracuse','ACC');
INSERT into team (seed, school, conference) VALUES(10,'Temple','AAC');
INSERT into team (seed, school, conference) VALUES(10,'Ole Miss','SEC');
INSERT into team (seed, school, conference) VALUES(11,'VCU','A-10');
INSERT into team (seed, school, conference) VALUES(11,'New Mexico St.','WAC');
INSERT into team (seed, school, conference) VALUES(11,'Baylor','Big 12');
INSERT into team (seed, school, conference) VALUES(11,'Arizona St.','Pac 12');
INSERT into team (seed, school, conference) VALUES(11,'St. Johns (NY)','Big East');
INSERT into team (seed, school, conference) VALUES(11,'Ohio St.','Big 10');
INSERT into team (seed, school, conference) VALUES(12,'Saint Marys (CA)','WCC');
INSERT into team (seed, school, conference) VALUES(12,'Murray St.','OVC');
INSERT into team (seed, school, conference) VALUES(12,'Oregon','Pac 12');
INSERT into team (seed, school, conference) VALUES(12,'UC Irvine','Big West');
INSERT into team (seed, school, conference) VALUES(13,'Liberty','A-Sun');
INSERT into team (seed, school, conference) VALUES(13,'Vermont','Am. East');
INSERT into team (seed, school, conference) VALUES(13,'Yale','Ivy');
INSERT into team (seed, school, conference) VALUES(13,'Northeastern','CAA');
INSERT into team (seed, school, conference) VALUES(14,'Georgia St.','Sunbelt');
INSERT into team (seed, school, conference) VALUES(14,'Old Dominion','C-USA');
INSERT into team (seed, school, conference) VALUES(14,'Northern Ky.','Horizon');
INSERT into team (seed, school, conference) VALUES(14,'Saint Louis','A-10');
INSERT into team (seed, school, conference) VALUES(15,'Montana','Big Sky');
INSERT into team (seed, school, conference) VALUES(15,'Abilene Christian','Southland');
INSERT into team (seed, school, conference) VALUES(15,'Colgate','Patriot');
INSERT into team (seed, school, conference) VALUES(15,'Gardner-Webb','Big South');
INSERT into team (seed, school, conference) VALUES(16,'Texas Southern','SWAC');
INSERT into team (seed, school, conference) VALUES(16,'Bradley','MVC');
INSERT into team (seed, school, conference) VALUES(16,'North Dakota St.','Summit');
INSERT into team (seed, school, conference) VALUES(16,'Fairleigh Dickinson','NEC');
INSERT into team (seed, school, conference) VALUES(16,'Iona','MAAC');
INSERT into team (seed, school, conference) VALUES(16,'N.C. Central','MEAC');
