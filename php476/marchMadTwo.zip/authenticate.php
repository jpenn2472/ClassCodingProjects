<?php

session_start();

// TODO: create a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "march";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// TODO: create variables for the input form data
$user = $_POST['enduser'];
$password = $_POST['userpass'];
// TODO: query the database for the input user's credentials
$sql = "SELECT password FROM users WHERE username='$user'";
$get = $conn->query($sql);
while ($row = $get->fetch_assoc()) {
    $dbPwd = $row['password'];
}
// TODO: authenticate the user using password_verify
$result = password_verify($password, $dbPwd);
if ($result) {
    $_SESSION['username'] = $user;
} else {
    $_SESSION['error'] = "Invalid username or password.";
}
// if the input credentials are valid, put the user in the SESSION 
// (similar to the 'Bogus user' example below) and clear 
// the "error" in the session
// otherwise, put "invalid username or password" in the session using 
// the "error" key
// TODO: close the database connection
// TODO: remove this line of code that mimics a valid user


header("location:index.php");
?>
