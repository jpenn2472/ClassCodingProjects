<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>March Madness Database</h2>
        <?php
        if (isset($_SESSION['error'])) {
            echo "<em>" . $_SESSION['error'] . "</em>";
        }
        if (isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
            header("location:select.php");
        } else {
            ?>
            <h3>Login</h3>
            <form action="authenticate.php" method="post">
                Username: <input type="text" name="enduser"><br>
                Password: <input type="password" name="userpass"><br>
                <input type="submit">
            </form>
            <p/>
            <a href="register.php">New User? Click here to register.</a>
            <?php
        }
        ?>
    </body>
</html>
