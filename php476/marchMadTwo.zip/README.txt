I have removed or altered four files from my working solution.

Tip: if you read all of the existing code and study the instructions FIRST,
it will save you a lot of time.

1. removed menu.html 
 - this file contains a snippet of HTML, i.e., not a complete HTML document
 - displays "Menu" followed by four links to the four CRUD pages
 - You don't have to use the "include" technique, but you must produce a menu
   that looks like this:
     Menu
     * Create
     * Read
     * Update
     * Delete

2. select.php (performs the Read/select operation)
 - display all table data except id
 - the display order must be based on the seed value
3. do_update (processes data from the display_for_update page)
4. authenticate.php (processes data from the Login form)
